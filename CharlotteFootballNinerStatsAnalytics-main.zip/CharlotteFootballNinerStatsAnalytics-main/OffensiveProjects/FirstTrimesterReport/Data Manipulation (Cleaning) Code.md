https://app.hex.tech/85371e2a-dc5e-44c9-8028-8d17b3d18e74/hex/5312ec4a-760f-4f44-b83c-3e70825288f2/draft/logic

Above is a link to the full script using both Python and SQL to scrape and clean both the PFF and Catapult for the use of this report.

