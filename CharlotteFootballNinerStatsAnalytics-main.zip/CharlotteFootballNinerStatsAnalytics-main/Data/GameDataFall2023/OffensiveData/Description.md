Here lies all offensive data for the 2023 Season.
