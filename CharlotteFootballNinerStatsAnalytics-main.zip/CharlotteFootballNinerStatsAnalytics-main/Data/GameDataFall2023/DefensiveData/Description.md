Here lies all defensive data for the 2023 season.
