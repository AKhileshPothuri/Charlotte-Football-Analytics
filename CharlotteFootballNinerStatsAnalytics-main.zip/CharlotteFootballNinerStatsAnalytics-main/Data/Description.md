Folder for all data pertaining to the team.
